---
name: unique-app-builder
description: Use when researching, scaffolding, or theming a new Lovable app or website, or when adding unique motion, Special FX, or tab-click animations. Not for one-line copy tweaks, unrelated backend-only work, or generic SaaS restyles that keep Inter, glass, and purple gradients.
---

# Unique App Builder

Research first. Then build a distinct app shell. Then wire theme tokens and Special FX so **every tab/nav click plays two animations**: chrome on the tab, plus a different stage overlay on the content.

Pipeline on a greenfield app:

```
1. Research brief
2. App shell (nav + stage + fx overlay)
3. Theme tokens + fonts
4. Screens with real copy
5. Per-tab stage FX
6. Reduced-motion pass
```

Do not skip research. Do not start from a hero + 3-icon grid. Do not ship a sliding underline as the only click feedback.

This skill targets Lovable apps (React + TypeScript + Tailwind + CSS). Restyle shadcn; do not use default `Tabs` chrome as the final nav.

---

## 1. Research (before UI)

Write a brief, then build. Infer missing audience/job from context and label the inference. Search the web when the domain is unfamiliar.

### Product thesis

One short paragraph each: who (specific, not "everyone"), the job they hire this for, frequency, what success feels like.

### Unique angle

One sentence: `This is the ___ for people who ___.`

Then 3 non-negotiable differentiators (structure, voice, motion, or workflow — not "clean UI").

### Competitor map

3–6 real products. For each: name, what they do well, what feels tired, one pattern to steal, one to reject.

### Information architecture

- Home surface: pick **one** — app shell, index/directory, narrative scroll, or asymmetric split
- Primary nav: max 6 items, product language (`Ledger`, `Run sheet`), not template names (`Dashboard`, `Features`) unless those are actually correct
- 5–12 named screens with one-line purpose each

### Content

List objects, fields, empty states, error states. Draft 3–5 lines of real UI copy. No lorem, no "Welcome back, John."

### Motion

Name 1 primary FX family and a **stage FX id per tab** from the catalog below. Say what must stay still (reading text, forms, tables).

### Research brief output

```
RESEARCH BRIEF — [product name]

Thesis
[who, job, frequency, success]

Unique angle
This is the ___ for people who ___.
1. ...
2. ...
3. ...

Competitors
- [Name]: steal ___ / reject ___

Audience + voice
[words we use / never use]

Information architecture
Home surface: [app shell | index | narrative scroll | split]
Nav: [...]
Screens:
- [Name] — [purpose]

Content objects
- [Object]: fields [...]; empty: "..."; error: "..."

Visual references
- [Named reference] → [what we take]

Motion language
Primary FX family: [...]
Tab secondary FX: [tab id → fx id]
Must stay still: [...]

Do not build
- Purple/blue gradient, glassmorphism, Inter-only type
- Centered hero + 3-icon grid
- Tab underline as the only click animation
```

Present the brief as the brief. Then implement.

---

## 2. Build rules

- App shell stays mounted; only the stage swaps
- Unique layout from the brief (asymmetric, editorial, directory-first, sidebar app, etc.)
- Display font + distinct body font (Google Fonts is fine)
- Theme via CSS variables in `src/index.css` (or `src/App.css`); Tailwind consumes those variables
- Real empty/error states
- Semantic HTML, keyboard tabs, `prefers-reduced-motion`
- FX overlay is a sibling of the stage, reused, `pointer-events: none`, `aria-hidden`
- Deep links / first paint: **no** stage FX
- Do not animate reading text, inputs, or data tables as part of FX
- Skip generic marketing chrome unless the brief's home surface is a marketing page

### Hard avoid

- Purple-to-blue gradients, glass cards, Inter/Poppins/Manrope as both display and body
- Centered hero + two pills + 3-icon feature grid
- Uniform 16–24px radius on every card/button
- Confetti, sparkle loops, purple glow orbs, bounce-in icons on every tab
- Full-screen Lottie; particle systems that run forever after click
- "Lorem ipsum", "TODO", "Your headline here"

### Motion personality (pick one)

| Mood | Ease | Duration | Chrome | Typical stage FX |
|---|---|---|---|---|
| Editorial / print | `cubic-bezier(0.2, 0.7, 0.1, 1)` | 640–800ms | `tab-ink` | `paper-fold`, `stamp-press` |
| Terminal / infra | `linear` or stepped | 280–480ms | `tab-phosphor` | `crt-wipe`, `scan-tear` |
| Luxury dark | `cubic-bezier(0.22, 1, 0.32, 1)` | 800–1100ms | `tab-stamp` | `ember-rise`, `veil-draw` |
| Brutal / pop | `cubic-bezier(0.75, 0, 0.25, 1)` | 220–360ms | `tab-cut` | `shard-burst`, `poster-slam` |
| Organic / craft | `cubic-bezier(0.34, 1.2, 0.64, 1)` | 700–900ms | `tab-drip` | `liquid-morph`, `dust-settle` |

Chrome and stage must not be the same trick. Do not pair `tab-ink` with `ink-bloom` unless the brief is explicitly all-ink.

---

## 3. FX catalog

Each tab click = **chrome** (tab) + **stage** (overlay). Each tab may use a different stage FX.

### Stage FX (second animation)

- `ink-bloom` — stain expands from the tab x-position, dissolves (editorial)
- `paper-fold` — diagonal peel/crease, not a card flip (print, archives)
- `crt-wipe` — phosphor scan bar + brief chromatic offset (terminal)
- `scan-tear` — ragged scanline tears the old panel down
- `ember-rise` — few slow sparks + warm veil from the bottom (luxury dark)
- `veil-draw` — accent curtain left→right, then transparent
- `shard-burst` — 5–7 large polygons translate out, no glitter
- `poster-slam` — hard snap + 12% accent flash
- `liquid-morph` — blob clip-path reveal (craft, ceramic)
- `dust-settle` — grain overlay fades (earth, concrete)
- `stamp-press` — hairline frame + slight scale press
- `aurora-cut` — one sharp diagonal clip (rare; cold palettes)

### Chrome FX (first animation)

- `tab-ink` — underline scales X from the click side
- `tab-stamp` — label 1 → 0.96 → 1, accent rule appears
- `tab-phosphor` — label flickers to accent; 120ms block suffix
- `tab-cut` — instant color + 2px offset shadow that slams home
- `tab-drip` — accent paint drips 6–10px under the label

Example assignment:

```
Ledger    → ink-bloom
Vault     → paper-fold
Run sheet → ember-rise
```

---

## 4. Implementation kit

Put tokens in `src/index.css`. Put overlay CSS in the same file (or `src/styles/fx.css`). Build `FxTabs` + `AppShell` as custom components. Do not use stock shadcn Tabs for primary nav.

### Tokens

```css
:root {
  --bg: #14110f;
  --surface: #1e1a16;
  --text: #ede3d3;
  --muted: #b7aa96;
  --accent: #e8a33d;
  --accent-2: #4a5a48;
  --line: color-mix(in oklab, var(--text) 18%, transparent);
  --font-display: "Fraunces", serif;
  --font-body: "Source Serif 4", serif;
  --font-ui: "IBM Plex Sans", sans-serif;
  --ease-fx: cubic-bezier(0.2, 0.8, 0.2, 1);
  --fx-ms: 720ms;
}

html, body, #root { height: 100%; }
body {
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font-family: var(--font-body);
}
h1, h2, h3, .display { font-family: var(--font-display); }

@media (prefers-reduced-motion: reduce) {
  :root { --fx-ms: 1ms; }
  .fx-overlay { display: none !important; }
}
```

Replace hex and fonts from the brief. Load fonts via Google Fonts in `index.html`.

### `FxTabs.tsx`

```tsx
import { useId } from "react";

export type Tab = {
  id: string;
  label: string;
  fx: string;
};

type Props = {
  tabs: Tab[];
  active: string;
  onChange: (id: string, fx: string, el: HTMLButtonElement) => void;
};

export function FxTabs({ tabs, active, onChange }: Props) {
  const base = useId();

  return (
    <div role="tablist" aria-label="Primary" className="fx-tabs">
      {tabs.map((tab) => {
        const selected = tab.id === active;
        return (
          <button
            key={tab.id}
            id={`${base}-${tab.id}`}
            role="tab"
            type="button"
            aria-selected={selected}
            className="fx-tab"
            data-active={selected}
            onClick={(e) => onChange(tab.id, tab.fx, e.currentTarget)}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}
```

### `AppShell.tsx`

First paint must not play FX. Replay: clear `data-fx`, then set it on the next frame. Swap the panel at ~50% of `--fx-ms` so the overlay covers the cut (`poster-slam` / `tab-cut`: swap immediately).

```tsx
import { useRef, useState } from "react";
import { FxTabs, type Tab } from "./FxTabs";

const TABS: Tab[] = [
  { id: "ledger", label: "Ledger", fx: "ink-bloom" },
  { id: "vault", label: "Vault", fx: "paper-fold" },
  { id: "run", label: "Run sheet", fx: "ember-rise" },
];

const FX_MS = 720;

export function AppShell({ panels }: { panels: Record<string, React.ReactNode> }) {
  const [active, setActive] = useState(TABS[0].id);
  const [fx, setFx] = useState("");
  const stageRef = useRef<HTMLElement>(null);
  const first = useRef(true);

  function select(id: string, nextFx: string, tabEl: HTMLButtonElement) {
    if (id === active) return;
    const stage = stageRef.current;
    if (stage) {
      const t = tabEl.getBoundingClientRect();
      const s = stage.getBoundingClientRect();
      stage.style.setProperty("--fx-x", `${((t.left + t.width / 2 - s.left) / s.width) * 100}%`);
    }
    if (first.current) {
      first.current = false;
      setActive(id);
      return;
    }
    setFx("");
    requestAnimationFrame(() => setFx(nextFx));
    window.setTimeout(() => setActive(id), FX_MS * 0.5);
  }

  return (
    <div className="app-shell">
      <header className="app-masthead">
        <p className="display">Product name</p>
        <FxTabs tabs={TABS} active={active} onChange={select} />
      </header>
      <main className="app-stage" ref={stageRef}>
        <div
          className="fx-overlay"
          data-fx={fx}
          onAnimationEnd={() => setFx("")}
          aria-hidden
        />
        <section role="tabpanel">{panels[active]}</section>
      </main>
    </div>
  );
}
```

Replace `TABS` and product name from the brief.

### Shell + chrome CSS

```css
.app-shell { min-height: 100%; display: grid; grid-template-rows: auto 1fr; }
.app-masthead {
  display: flex;
  align-items: end;
  justify-content: space-between;
  gap: 1.5rem;
  padding: 1.25rem 1.5rem 0.75rem;
  border-bottom: 1px solid var(--line);
}
.fx-tabs { position: relative; display: flex; gap: 0.25rem; }
.fx-tab {
  appearance: none;
  background: none;
  border: 0;
  color: var(--muted);
  font: 600 0.92rem/1 var(--font-ui);
  padding: 0.65rem 0.85rem;
  cursor: pointer;
  position: relative;
}
.fx-tab[data-active="true"] { color: var(--text); }
.fx-tab[data-active="true"]::after {
  content: "";
  position: absolute;
  left: 0.85rem;
  right: 0.85rem;
  bottom: 0.2rem;
  height: 2px;
  background: var(--accent);
  transform-origin: left;
  animation: tab-ink var(--fx-ms) var(--ease-fx) both;
}
@keyframes tab-ink {
  from { transform: scaleX(0); opacity: 0; }
  to { transform: scaleX(1); opacity: 1; }
}
.app-stage { position: relative; isolation: isolate; }
.fx-overlay {
  pointer-events: none;
  position: absolute;
  inset: 0;
  z-index: 2;
  overflow: hidden;
}
.fx-overlay[data-fx=""] { display: none; }
.fx-overlay[data-fx]::before,
.fx-overlay[data-fx]::after {
  content: "";
  position: absolute;
  inset: 0;
}
```

### Stage FX CSS

```css
.fx-overlay[data-fx="ink-bloom"]::before {
  background: radial-gradient(circle at var(--fx-x, 50%) 0%,
    color-mix(in oklab, var(--accent-2) 80%, #000) 0%,
    transparent 62%);
  animation: ink-bloom var(--fx-ms) var(--ease-fx) both;
}
@keyframes ink-bloom {
  0% { transform: scale(0.2); opacity: 0; filter: blur(0); }
  40% { transform: scale(1.15); opacity: 0.72; filter: blur(8px); }
  100% { transform: scale(1.5); opacity: 0; filter: blur(18px); }
}

.fx-overlay[data-fx="paper-fold"]::before {
  background: var(--surface);
  clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
  transform-origin: 0 0;
  animation: paper-fold var(--fx-ms) var(--ease-fx) both;
}
@keyframes paper-fold {
  0% { clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%); }
  55% { clip-path: polygon(0 0, 100% 0, 0 100%, 0 100%); }
  100% { clip-path: polygon(0 0, 0 0, 0 0, 0 0); }
}

.fx-overlay[data-fx="crt-wipe"]::before {
  background: linear-gradient(
    to bottom,
    transparent 0%,
    color-mix(in oklab, var(--accent) 45%, transparent) 48%,
    var(--accent) 50%,
    color-mix(in oklab, var(--accent) 45%, transparent) 52%,
    transparent 100%
  );
  animation: crt-wipe var(--fx-ms) linear both;
}
.fx-overlay[data-fx="crt-wipe"]::after {
  background: var(--bg);
  mix-blend-mode: multiply;
  opacity: 0.35;
  animation: crt-fade var(--fx-ms) linear both;
}
@keyframes crt-wipe {
  from { transform: translateY(-100%); }
  to { transform: translateY(100%); }
}
@keyframes crt-fade {
  0%, 70% { opacity: 0.35; }
  100% { opacity: 0; }
}

.fx-overlay[data-fx="ember-rise"]::before {
  background:
    radial-gradient(2px 2px at 12% 80%, var(--accent), transparent),
    radial-gradient(2px 2px at 28% 90%, var(--accent), transparent),
    radial-gradient(1.5px 1.5px at 61% 85%, var(--accent), transparent),
    radial-gradient(2px 2px at 81% 92%, var(--accent), transparent),
    linear-gradient(to top, color-mix(in oklab, var(--accent) 28%, transparent), transparent 42%);
  animation: ember-rise var(--fx-ms) var(--ease-fx) both;
}
@keyframes ember-rise {
  from { transform: translateY(18%); opacity: 0; }
  40% { opacity: 0.85; }
  to { transform: translateY(-8%); opacity: 0; }
}

.fx-overlay[data-fx="veil-draw"]::before {
  background: var(--accent);
  transform-origin: left center;
  animation: veil-draw var(--fx-ms) var(--ease-fx) both;
}
@keyframes veil-draw {
  0% { transform: scaleX(0); opacity: 1; }
  45% { transform: scaleX(1); opacity: 1; }
  100% { transform: scaleX(1); opacity: 0; }
}

.fx-overlay[data-fx="shard-burst"]::before,
.fx-overlay[data-fx="shard-burst"]::after {
  background: var(--surface);
  animation: shard var(--fx-ms) cubic-bezier(0.75, 0, 0.25, 1) both;
}
.fx-overlay[data-fx="shard-burst"]::before {
  clip-path: polygon(0 0, 70% 0, 40% 100%, 0 100%);
}
.fx-overlay[data-fx="shard-burst"]::after {
  clip-path: polygon(70% 0, 100% 0, 100% 100%, 40% 100%);
  animation-name: shard-2;
}
@keyframes shard {
  to { transform: translate3d(-18%, -8%, 0) rotate(-6deg); opacity: 0; }
}
@keyframes shard-2 {
  to { transform: translate3d(22%, 10%, 0) rotate(7deg); opacity: 0; }
}

.fx-overlay[data-fx="liquid-morph"]::before {
  background: color-mix(in oklab, var(--accent-2) 70%, var(--bg));
  clip-path: circle(0% at 50% 0%);
  animation: liquid-morph var(--fx-ms) var(--ease-fx) both;
}
@keyframes liquid-morph {
  0% { clip-path: circle(0% at 50% 0%); }
  45% { clip-path: circle(72% at 50% 30%); }
  100% { clip-path: circle(140% at 50% 40%); opacity: 0; }
}

.fx-overlay[data-fx="poster-slam"]::before {
  background: var(--accent);
  animation: poster-flash 220ms steps(2, end) both;
}
@keyframes poster-flash {
  0% { opacity: 0.2; }
  50% { opacity: 0.12; }
  100% { opacity: 0; }
}

.fx-overlay[data-fx="dust-settle"]::before {
  background-image: repeating-linear-gradient(
    -12deg,
    transparent,
    transparent 2px,
    color-mix(in oklab, var(--text) 12%, transparent) 3px
  );
  animation: dust-settle var(--fx-ms) linear both;
}
@keyframes dust-settle {
  from { transform: translateY(-6%); opacity: 0.4; }
  to { transform: translateY(4%); opacity: 0; }
}

.fx-overlay[data-fx="stamp-press"]::before {
  inset: 8%;
  border: 1px solid var(--accent);
  background: transparent;
  animation: stamp-press var(--fx-ms) var(--ease-fx) both;
}
@keyframes stamp-press {
  0% { transform: scale(1.04); opacity: 0; }
  35% { transform: scale(0.985); opacity: 1; }
  100% { transform: scale(1); opacity: 0; }
}

.fx-overlay[data-fx="scan-tear"]::before {
  background: repeating-linear-gradient(
    to bottom,
    var(--accent) 0 1px,
    transparent 1px 7px
  );
  animation: scan-tear var(--fx-ms) steps(12, end) both;
}
@keyframes scan-tear {
  from { transform: translateY(-30%); opacity: 0.7; }
  to { transform: translateY(40%); opacity: 0; }
}

.fx-overlay[data-fx="aurora-cut"]::before {
  background: var(--surface);
  clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%);
  animation: aurora-cut var(--fx-ms) var(--ease-fx) both;
}
@keyframes aurora-cut {
  0% { clip-path: polygon(0 0, 100% 0, 100% 100%, 0 100%); }
  100% { clip-path: polygon(100% 0, 100% 0, 100% 100%, 100% 100%); }
}
```

GPU-safe only: `transform`, `opacity`, `clip-path`, `filter`. Overlay never captures pointer events. Keyboard users must not wait on FX before focus.

---

## 5. After scaffold

1. Implement the 3–5 highest-traffic screens from the brief
2. Attach per-tab FX ids from the motion section
3. Verify reduced-motion: instant panel swap, no overlay
4. Verify first load / refresh does not play FX

In chat, invoke with `/unique-app-builder` then the product request, e.g. `/unique-app-builder Research and build a night-shift run sheet for kitchen managers.`
