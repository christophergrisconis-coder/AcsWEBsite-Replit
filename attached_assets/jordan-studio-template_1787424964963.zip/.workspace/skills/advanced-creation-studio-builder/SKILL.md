---
name: advanced-creation-studio-builder
description: Use when building web apps, dashboards, interactive guides, or tools for Advanced Creation Studios or questandguides.com, applying strict credit-conscious execution, verified functionality, custom dark/clean aesthetic themes, and business standards.
---

# Advanced Creation Studio & Quest Guides App Builder

## Overview & Core Objective
This skill defines the exact engineering standards, visual themes, business identity, and token/credit optimization protocols for building and maintaining projects for **Advanced Creation Studios** and **questandguides.com**.

---

## 1. Credit-Conscious & Zero-Waste Protocol
Lovable credits and AI tokens are valuable. Prevent costly back-and-forth cycles, hallucinated builds, and iterative patching loops by adhering to the following rules:

- **Stop & Ask (Zero Guessing)**: If requirements, schema, assets, logic, or edge cases are missing or ambiguous, **STOP immediately and prompt the user for clarification**. Do not guess, do not produce half-baked placeholder code that wastes credits, and do not make assumptions.
- **One Clean Build over Endless Patches**: If an approach fails or breaks twice, halt incremental patching. Rebuild or refactor the component cleanly from scratch in one complete execution.
- **No Hallucinated or Fake Interactivity**: Never create dummy buttons, fake tabs, non-functioning filter bars, or decorative toggles that do nothing. Every control must be tied to active state, live handlers, or real data models.
- **Direct & Concise Communication**: Lead with the working deliverable. Do not output repetitive filler, conversational apologies, or lengthy narrations of what was done.

---

## 2. Business Context & Branding Information

### Entity 1: Advanced Creation Studios
- **Core Focus**: Web and application development, modern digital tools, digital business cards, interactive dashboards, and client-facing technology solutions.
- **Brand Identity**: Modern, high-performance, polished, professional, cutting-edge, and utility-driven.

### Entity 2: Quest & Guides (`questandguides.com`)
- **Core Focus**: Comprehensive, highly visual, interactive video game walkthroughs, quest trackers, completion guides, and databases for top adventure, shooter, open-world, and extraction titles (e.g., Red Dead Redemption 2, ARC Raiders, Zelda: Breath of the Wild, 007 First Light, Elden Ring, The Witcher 3).
- **Brand Identity**: Immersive, gamer-centric, highly structured, easily searchable, responsive, and readable.

---

## 3. UI/UX & Design Theme Standards

When building interfaces, strictly follow the visual hierarchy:
**1. Visible Functionality First** → **2. Real Interaction Second** → **3. Styling Third**

### Color Palette & Theme Specs
- **Default Style**: Modern Dark Mode / High-Contrast Clean Slate.
- **Backgrounds**: Deep Charcoal / Rich Slate / True Dark (`#0B0F17`, `#0F172A`, `#1E293B`).
- **Surface / Cards**: Slightly elevated contrasting panels (`#182234`, `#1E293B`, `rgba(255, 255, 255, 0.05)`) with subtle borders (`#334155` or `1px solid rgba(255, 255, 255, 0.1)`).
- **Accents & Highlights**: Electric Cyan / Neon Teal / Vibrant Amber (`#06B6D4`, `#10B981`, `#F59E0B`) for active states, CTA buttons, badges, and progress indicators.
- **Typography**: Clean, readable sans-serif (Inter, Roboto, Space Grotesk, or Tailwind standard sans) with distinct heading weights and generous line-height.
- **Interactive States**: Smooth hover transitions, clear active/selected indicators, accessible focus outlines, and responsive tactile feedback.

---

## 4. Architectural & Development Guidelines

### Interactive Systems & Features
- **Dashboards & Trackers**: Always implement functional state (e.g., React `useState`, `useReducer`, or Zustand), localStorage persistence where suitable, filter/sort logic, and dynamic progress calculation.
- **Quest / Guide Systems**: Include structured chapter navigation, searchable quest lists, checkable completion states, interactive checklists, difficulty badges, reward breakdowns, and fast text filtering.
- **Copy-Paste & Modular Code**: Write modular, clean TypeScript/React components with Tailwind CSS. Ensure dependencies are standard and self-contained.

---

## 5. Verification Checklist Before Delivery
Before presenting or completing any feature:
1. Are all tabs, buttons, dropdowns, and inputs visibly interactive and wired to state?
2. Is the design fully responsive across mobile, tablet, and desktop viewports?
3. Are all theme variables, dark mode contrasts, and typography hierarchies properly applied?
4. Is the code free of placeholder `TODOs` and non-functional mock handlers?
5. Did this execution avoid unnecessary credit-wasting iterations?