# Expo Snack Compatibility

## Portability Strategy

Prefer a single `App.js` with React Native core components and Expo-provided libraries. Use local state for navigation when a full router is unnecessary. This reduces setup steps and makes the result easy to paste into a blank Snack.

| Need | Portable default |
| --- | --- |
| Navigation among a few prototype screens | Local `activeTab` state and a real bottom navigation component. |
| Icons | `@expo/vector-icons`, declared in dependencies. |
| Images | Static local `require("./assets/name.ext")` references. |
| Contact action | Validated form followed by `Linking.openURL("mailto:...")`. |
| External website | `Linking.openURL` with a verified HTTPS URL. |
| Temporary data | React state; use device storage only when persistence is explicitly required. |
| Full-screen artwork | React Native `Modal` with a working close action. |

## Dependency Rules

Declare every imported non-relative package in `package.json`. Match React and React Native versions to the selected Expo SDK. Keep packages within Expo Go support; native modules requiring custom configuration or a development build do not belong in the portable Snack edition.

Do not copy the managed project’s backend, database, authentication, server, environment variables, or router structure into Snack unless the user explicitly needs a demonstration of those capabilities and the dependencies run in Expo Go.

## Asset Rules

Place local images under `assets/` beside `App.js`. Use exact, case-sensitive filenames. Avoid absolute filesystem paths and project-only aliases. Verify every `require()` target exists before packaging.

Keep the icon square and at least 1024 by 1024 pixels in the source package. Compress campaign artwork enough for responsive Snack loading while retaining readable text. Preserve the original aspect ratio unless the user approves a crop.

## Interaction Rules

Every tab must change visible content. Every pressable control must have an action and pressed feedback. Forms must validate required fields before launching external actions. Show honest errors when the device cannot handle a URL.

Do not claim a message was sent merely because an email composer opened. Do not include an invented recipient. If a verified recipient is unavailable, define an empty `CONTACT_EMAIL` constant and flag it in the handoff.

## Package Metadata

Set a short app name, stable slug, portrait orientation when appropriate, local icon path, and explicit asset bundling in `app.json`. Keep the Snack `package.json` minimal and avoid scripts that Snack does not use.
