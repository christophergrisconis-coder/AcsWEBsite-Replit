# End-to-End Workflow

## 1. Intake and Evidence Capture

Create a source inventory before design work. Record each supplied PDF, image, slide deck, source project, logo file, and exact copy block. Read visual files with multimodal tools and save findings immediately so they are not lost from context.

Use the following evidence hierarchy when source material conflicts:

| Priority | Source |
| --- | --- |
| 1 | Explicit instructions in the user’s current request. |
| 2 | Approved brand guidelines or identity standards. |
| 3 | Supplied production assets and existing application behavior. |
| 4 | Presentation examples and generated concepts. |
| 5 | Reasonable implementation assumptions, clearly disclosed. |

Extract exact brand colors when visible, but do not claim uncertain values as official. Preserve logo clear space and contrast. Treat typography named in the brand kit as direction; for Snack portability, use system-safe fonts unless custom font files are supplied and configured.

## 2. Scope and Architecture

Define the app’s job in one sentence. Select the smallest screen set that completes that job. A common public information structure is Overview, Services or Programs, Impact or Evidence, and Contact, but adapt it rather than forcing it.

Use local state and local assets for a portable Snack unless the request genuinely requires persistence or network data. If the production project uses routing or backend features, preserve those in the managed project while maintaining a dependency-light Snack demonstration.

## 3. Design Plan

Write `design.md` with a screen table, content hierarchy, key flows, and brand-specific color table. State what every primary button does. Flag any unknown recipient address, URL, metric, legal disclaimer, or claim as a release dependency.

Write `todo.md` before implementation. Include design, assets, icon, each screen, every interaction, Snack packaging, tests, and delivery.

## 4. Asset Production

Create only assets needed by the interface. For existing designs, compress and resize without changing composition. Keep high-resolution originals outside the Snack bundle; package mobile derivatives.

Use JPEG for opaque photographic or campaign artwork and PNG for transparency, line art, or icons. Prefer dimensions that remain clear on high-density phones without shipping multi-megabyte source files. Use the bundled asset script for repeatability.

For a new app icon, generate a simple square mark that reflects the brand purpose. Avoid words, fine detail, rounded-corner masks, device mockups, and empty border space. Install the same prepared icon in the Expo icon, splash, favicon, Android foreground, and Snack locations unless platform-specific art is intentionally required.

## 5. Implementation

Build one screen at a time in this order: visible content, navigation, actions, validation and feedback, then polish. Use `FlatList` for repeated long content. Use safe-area handling, readable line heights, 44-point-or-larger practical touch targets, and clear pressed states.

Do not create a button without its final action. If a backend is unavailable, choose an honest local alternative such as opening email, opening a verified URL, copying text, or displaying an unavailable state. Never simulate submission success when nothing was sent.

Keep the Snack `App.js` self-contained. Store content arrays and theme constants near the top, reusable components in the middle, screens below them, and styles at the end. This structure is easy to paste into a new Snack and easy to adapt.

## 6. Verification

Validate in layers. First run type checking and lint. Next run unit or static compatibility tests. Then bundle or export the Expo project to catch module and asset resolution failures. Finally inspect each user flow against `todo.md`.

Do not rely on a web preview as proof of native behavior. For device-specific actions such as email composition, document the expected Expo Go test and provide a graceful failure message.

## 7. Handoff

Create the final Snack ZIP with `App.js`, metadata, instructions, and all required assets at the archive root. Confirm the archive does not contain another nested `snack` folder.

Deliver a concise report covering what exists, what passed, and what release-specific information remains. Common remaining values include a verified contact email, production URLs, real metrics, legal copy, or API credentials.
