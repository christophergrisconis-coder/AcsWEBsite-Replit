# Quality Gates

## Brand and Content

| Gate | Pass condition |
| --- | --- |
| Brand extraction | Colors, typography direction, logo use, tone, visual motifs, and approved messaging are documented. |
| Source integrity | Generated concepts and sample data are clearly distinguished from verified facts. |
| Mobile translation | The interface reflects the brand without simply shrinking a presentation slide onto a phone. |
| Release values | Missing emails, URLs, metrics, and legal text are explicit configuration items rather than inventions. |

## Functionality

| Gate | Pass condition |
| --- | --- |
| Navigation | Every visible tab and primary navigation action changes to the intended content. |
| Buttons | Every button performs a real action; no empty or decorative controls remain. |
| Forms | Required fields validate, malformed input is rejected, and success is not falsely implied. |
| Media | Every bundled image loads and every modal or viewer has a working exit path. |
| Failure handling | External actions show a useful error when the platform cannot complete them. |

## Expo and Snack

| Gate | Pass condition |
| --- | --- |
| Type checking | The managed project’s type-check command exits successfully. |
| Lint | The project lint command exits without errors. Warnings must be understood and disclosed when relevant. |
| Bundle | An Expo export or bundle command resolves all modules and local assets. |
| Snack validation | `validate_snack.py` exits successfully for the target SDK. |
| Package contents | The ZIP contains `App.js`, `app.json`, `package.json`, `HANDOFF.md`, and every required asset. |

## Mobile UX

| Gate | Pass condition |
| --- | --- |
| Safe areas | Content avoids device notches, status areas, and home indicators. |
| Touch targets | Primary actions are comfortable for one-handed use and include pressed feedback. |
| Readability | Text has sufficient contrast, practical line height, and no visible clipping. |
| Lists | Long repeated content uses a scalable list pattern rather than an unbounded mapped scroll view. |
| Claims | The UI does not publish unverified impact data or implied endorsements. |

## Handoff

Review the complete `todo.md` immediately before checkpointing or packaging. Mark every fulfilled item complete and leave any unresolved release dependency visible. Deliver the project/checkpoint and the Snack ZIP according to the user’s requested format, with concise setup steps and no claim of native verification that was not performed.
