import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import React, { useMemo, useState } from "react";
import {
  Alert,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Linking,
  Modal,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";

const THEME = {
  dark: "{{BRAND_DARK}}",
  primary: "{{BRAND_PRIMARY}}",
  accent: "{{BRAND_ACCENT}}",
  background: "{{BRAND_LIGHT}}",
  white: "#FFFFFF",
  ink: "#122033",
  muted: "#697386",
  border: "#DDE5F0",
  error: "#B42318",
};

const CONTACT_EMAIL = "{{CONTACT_EMAIL}}";

const TABS = [
  { key: "home", label: "Home", icon: "home" },
  { key: "services", label: "Services", icon: "view-list" },
  { key: "evidence", label: "Evidence", icon: "insights" },
  { key: "contact", label: "Contact", icon: "mail-outline" },
];

const SERVICES = [
  {
    id: "service-one",
    icon: "route",
    title: "{{SERVICE_ONE_TITLE}}",
    description: "{{SERVICE_ONE_DESCRIPTION}}",
  },
  {
    id: "service-two",
    icon: "work-outline",
    title: "{{SERVICE_TWO_TITLE}}",
    description: "{{SERVICE_TWO_DESCRIPTION}}",
  },
  {
    id: "service-three",
    icon: "groups",
    title: "{{SERVICE_THREE_TITLE}}",
    description: "{{SERVICE_THREE_DESCRIPTION}}",
  },
];

const ARTWORK = {
  hero: require("./assets/campaign-hero.jpg"),
  square: require("./assets/campaign-square.jpg"),
};

function Button({ label, icon = "arrow-forward", onPress, light = false }) {
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        light ? styles.buttonLight : styles.buttonPrimary,
        pressed && styles.pressed,
      ]}
    >
      <Text style={[styles.buttonText, light && styles.buttonTextDark]}>{label}</Text>
      <MaterialIcons name={icon} size={20} color={light ? THEME.dark : THEME.white} />
    </Pressable>
  );
}

function Heading({ eyebrow, title, body }) {
  return (
    <View style={styles.heading}>
      <Text style={styles.eyebrow}>{eyebrow}</Text>
      <Text style={styles.headingTitle}>{title}</Text>
      {body ? <Text style={styles.headingBody}>{body}</Text> : null}
    </View>
  );
}

function Header() {
  return (
    <View style={styles.header}>
      <View style={styles.logoMark}>
        <MaterialIcons name="arrow-forward" size={24} color={THEME.white} />
      </View>
      <View style={styles.headerCopy}>
        <Text style={styles.headerTitle}>{{APP_SHORT_NAME}}</Text>
        <Text style={styles.headerSubtitle}>{{APP_CATEGORY}}</Text>
      </View>
    </View>
  );
}

function ArtworkCard({ title, source, ratio, onOpen }) {
  return (
    <Pressable
      accessibilityRole="imagebutton"
      accessibilityLabel={`Open ${title}`}
      onPress={() => onOpen({ title, source })}
      style={({ pressed }) => [styles.artCard, pressed && styles.pressed]}
    >
      <Image source={source} resizeMode="cover" style={[styles.artImage, { aspectRatio: ratio }]} />
      <View style={styles.artCaption}>
        <Text style={styles.artTitle}>{title}</Text>
        <MaterialIcons name="open-in-full" size={20} color={THEME.primary} />
      </View>
    </Pressable>
  );
}

function HomeScreen({ goTo, openArtwork }) {
  return (
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.hero}>
        <Text style={styles.heroEyebrow}>{{HERO_EYEBROW}}</Text>
        <Text style={styles.heroTitle}>{{TAGLINE}}</Text>
        <Text style={styles.heroBody}>{{POSITIONING_BODY}}</Text>
        <View style={styles.actionStack}>
          <Button label="Explore Services" onPress={() => goTo("services")} />
          <Button label="Evidence Approach" icon="insights" light onPress={() => goTo("evidence")} />
        </View>
      </View>

      <Heading
        eyebrow="FEATURED WORK"
        title="{{GALLERY_HEADING}}"
        body="Tap any design to inspect the mobile-ready asset at full size."
      />
      <ArtworkCard title="{{HERO_ART_TITLE}}" source={ARTWORK.hero} ratio={16 / 9} onOpen={openArtwork} />
      <ArtworkCard title="{{SQUARE_ART_TITLE}}" source={ARTWORK.square} ratio={1} onOpen={openArtwork} />

      <View style={styles.cta}>
        <MaterialIcons name="handshake" size={30} color={THEME.accent} />
        <Text style={styles.ctaTitle}>{{CTA_HEADING}}</Text>
        <Text style={styles.ctaBody}>{{CTA_BODY}}</Text>
        <Button label="Start a Conversation" onPress={() => goTo("contact")} />
      </View>
    </ScrollView>
  );
}

function ServicesScreen({ discuss }) {
  return (
    <FlatList
      data={SERVICES}
      keyExtractor={(item) => item.id}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
      ListHeaderComponent={
        <Heading
          eyebrow="WHAT WE DO"
          title="{{SERVICES_HEADING}}"
          body="{{SERVICES_INTRO}}"
        />
      }
      ItemSeparatorComponent={() => <View style={styles.gap} />}
      renderItem={({ item, index }) => (
        <View style={styles.serviceCard}>
          <View style={styles.serviceTop}>
            <View style={styles.serviceIcon}>
              <MaterialIcons name={item.icon} size={25} color={THEME.primary} />
            </View>
            <Text style={styles.serviceNumber}>{String(index + 1).padStart(2, "0")}</Text>
          </View>
          <Text style={styles.serviceTitle}>{item.title}</Text>
          <Text style={styles.serviceBody}>{item.description}</Text>
          <Pressable
            accessibilityRole="button"
            onPress={() => discuss(item.title)}
            style={({ pressed }) => [styles.textAction, pressed && styles.pressed]}
          >
            <Text style={styles.textActionLabel}>Discuss this service</Text>
            <MaterialIcons name="arrow-forward" size={19} color={THEME.primary} />
          </Pressable>
        </View>
      )}
    />
  );
}

function EvidenceScreen({ goTo, openArtwork }) {
  return (
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <Heading eyebrow="ACCOUNTABILITY" title="{{EVIDENCE_HEADING}}" body="{{EVIDENCE_INTRO}}" />
      <View style={styles.notice}>
        <MaterialIcons name="fact-check" size={26} color={THEME.primary} />
        <View style={styles.noticeCopy}>
          <Text style={styles.noticeTitle}>Verified information only</Text>
          <Text style={styles.noticeBody}>
            Replace this state with approved metrics and cite the population, period, source, and method.
          </Text>
        </View>
      </View>
      <ArtworkCard title="{{EVIDENCE_ART_TITLE}}" source={ARTWORK.square} ratio={1} onOpen={openArtwork} />
      <View style={styles.darkCard}>
        <Text style={styles.darkCardTitle}>{{EVIDENCE_CTA_HEADING}}</Text>
        <Text style={styles.darkCardBody}>{{EVIDENCE_CTA_BODY}}</Text>
        <Button label="Discuss the Evidence" onPress={() => goTo("contact")} />
      </View>
    </ScrollView>
  );
}

function ContactScreen({ initialTopic }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [organization, setOrganization] = useState("");
  const [message, setMessage] = useState(initialTopic ? `I would like to discuss ${initialTopic}.` : "");
  const [errors, setErrors] = useState({});

  const composeEmail = async () => {
    const next = {};
    if (!name.trim()) next.name = "Enter your name.";
    if (!email.trim()) next.email = "Enter your email.";
    else if (!/^\S+@\S+\.\S+$/.test(email.trim())) next.email = "Enter a valid email address.";
    if (!message.trim()) next.message = "Add a short message.";
    setErrors(next);
    if (Object.keys(next).length) return;

    const subject = encodeURIComponent(`Inquiry${organization.trim() ? ` — ${organization.trim()}` : ""}`);
    const body = encodeURIComponent(
      `Name: ${name.trim()}\nEmail: ${email.trim()}\nOrganization: ${organization.trim() || "Not provided"}\n\n${message.trim()}`,
    );
    try {
      await Linking.openURL(`mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`);
    } catch {
      Alert.alert("Email unavailable", "No email composer could be opened on this device.");
    }
  };

  const field = (key, label, value, setter, options = {}) => (
    <View style={styles.field}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={(next) => {
          setter(next);
          if (errors[key]) setErrors((current) => ({ ...current, [key]: undefined }));
        }}
        placeholder={options.placeholder}
        placeholderTextColor="#8C98A9"
        keyboardType={options.keyboardType}
        autoCapitalize={options.keyboardType === "email-address" ? "none" : "sentences"}
        multiline={options.multiline}
        textAlignVertical={options.multiline ? "top" : "center"}
        style={[styles.input, options.multiline && styles.inputMultiline, errors[key] && styles.inputError]}
      />
      {errors[key] ? <Text style={styles.errorText}>{errors[key]}</Text> : null}
    </View>
  );

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Heading eyebrow="CONTACT" title="{{CONTACT_HEADING}}" body="{{CONTACT_INTRO}}" />
        <View style={styles.formCard}>
          {field("name", "Name *", name, setName, { placeholder: "Your name" })}
          {field("email", "Email *", email, setEmail, {
            placeholder: "name@organization.com",
            keyboardType: "email-address",
          })}
          {field("organization", "Organization", organization, setOrganization, {
            placeholder: "Your organization",
          })}
          {field("message", "Message *", message, setMessage, {
            placeholder: "How can we help?",
            multiline: true,
          })}
          <Button label="Compose Email" icon="send" onPress={composeEmail} />
          <Text style={styles.privacy}>Entries remain on this device until the email composer opens.</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function ArtworkModal({ artwork, onClose }) {
  return (
    <Modal visible={Boolean(artwork)} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.modalBackdrop}>
        <View style={styles.modalPanel}>
          <View style={styles.modalHeader}>
            <Text numberOfLines={1} style={styles.modalTitle}>{artwork?.title}</Text>
            <Pressable onPress={onClose} style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}>
              <MaterialIcons name="close" size={24} color={THEME.dark} />
            </Pressable>
          </View>
          <Image source={artwork?.source} resizeMode="contain" style={styles.modalImage} />
        </View>
      </View>
    </Modal>
  );
}

function BottomNav({ active, onSelect }) {
  return (
    <View style={styles.bottomNav}>
      {TABS.map((tab) => {
        const selected = active === tab.key;
        return (
          <Pressable
            key={tab.key}
            accessibilityRole="tab"
            accessibilityState={{ selected }}
            onPress={() => onSelect(tab.key)}
            style={({ pressed }) => [styles.tab, pressed && styles.pressed]}
          >
            <MaterialIcons name={tab.icon} size={23} color={selected ? THEME.accent : "#8492A7"} />
            <Text style={[styles.tabText, selected && styles.tabTextActive]}>{tab.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export default function App() {
  const [active, setActive] = useState("home");
  const [artwork, setArtwork] = useState(null);
  const [topic, setTopic] = useState("");

  const discuss = (service) => {
    setTopic(service);
    setActive("contact");
  };

  const screen = useMemo(() => {
    if (active === "services") return <ServicesScreen discuss={discuss} />;
    if (active === "evidence") return <EvidenceScreen goTo={setActive} openArtwork={setArtwork} />;
    if (active === "contact") return <ContactScreen key={topic} initialTopic={topic} />;
    return <HomeScreen goTo={setActive} openArtwork={setArtwork} />;
  }, [active, topic]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor={THEME.dark} />
      <Header />
      <View style={styles.flex}>{screen}</View>
      <BottomNav active={active} onSelect={setActive} />
      <ArtworkModal artwork={artwork} onClose={() => setArtwork(null)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  safeArea: { flex: 1, backgroundColor: THEME.dark, paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0 },
  header: { minHeight: 66, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", backgroundColor: THEME.dark, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "#26354A" },
  logoMark: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center", backgroundColor: THEME.primary, marginRight: 11 },
  headerCopy: { flex: 1 },
  headerTitle: { color: THEME.white, fontSize: 14, lineHeight: 18, fontWeight: "900", letterSpacing: 1.1 },
  headerSubtitle: { color: THEME.accent, fontSize: 9, lineHeight: 13, fontWeight: "800", letterSpacing: 2 },
  content: { padding: 18, paddingBottom: 36, backgroundColor: THEME.background },
  hero: { backgroundColor: THEME.dark, borderRadius: 27, padding: 22 },
  heroEyebrow: { color: THEME.accent, fontSize: 10, lineHeight: 15, fontWeight: "900", letterSpacing: 1.4 },
  heroTitle: { color: THEME.white, fontSize: 34, lineHeight: 40, fontWeight: "900", letterSpacing: -1, marginTop: 14 },
  heroBody: { color: "#C9D7E8", fontSize: 15, lineHeight: 23, marginTop: 14 },
  actionStack: { gap: 10, marginTop: 23 },
  button: { minHeight: 50, borderRadius: 15, paddingHorizontal: 17, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderWidth: 1 },
  buttonPrimary: { backgroundColor: THEME.primary, borderColor: THEME.primary },
  buttonLight: { backgroundColor: THEME.white, borderColor: THEME.white },
  buttonText: { color: THEME.white, fontSize: 15, lineHeight: 20, fontWeight: "800" },
  buttonTextDark: { color: THEME.dark },
  pressed: { opacity: 0.74, transform: [{ scale: 0.98 }] },
  heading: { marginTop: 28, marginBottom: 15 },
  eyebrow: { color: THEME.primary, fontSize: 10, lineHeight: 15, fontWeight: "900", letterSpacing: 1.6 },
  headingTitle: { color: THEME.ink, fontSize: 27, lineHeight: 33, fontWeight: "900", letterSpacing: -0.6, marginTop: 6 },
  headingBody: { color: THEME.muted, fontSize: 14, lineHeight: 21, marginTop: 7 },
  artCard: { backgroundColor: THEME.white, borderRadius: 21, overflow: "hidden", marginBottom: 14, borderWidth: 1, borderColor: THEME.border },
  artImage: { width: "100%", backgroundColor: THEME.dark },
  artCaption: { minHeight: 58, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  artTitle: { flex: 1, color: THEME.ink, fontSize: 14, lineHeight: 19, fontWeight: "800", paddingRight: 10 },
  cta: { backgroundColor: THEME.dark, borderRadius: 23, padding: 20, marginTop: 8 },
  ctaTitle: { color: THEME.white, fontSize: 22, lineHeight: 28, fontWeight: "900", marginTop: 12 },
  ctaBody: { color: "#C9D7E8", fontSize: 13, lineHeight: 20, marginTop: 6, marginBottom: 16 },
  gap: { height: 13 },
  serviceCard: { backgroundColor: THEME.white, borderRadius: 22, padding: 19, borderWidth: 1, borderColor: THEME.border },
  serviceTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  serviceIcon: { width: 48, height: 48, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: `${THEME.primary}18` },
  serviceNumber: { color: "#C8D2DF", fontSize: 27, lineHeight: 33, fontWeight: "900" },
  serviceTitle: { color: THEME.ink, fontSize: 22, lineHeight: 28, fontWeight: "900", marginTop: 15 },
  serviceBody: { color: THEME.muted, fontSize: 14, lineHeight: 21, marginTop: 7 },
  textAction: { minHeight: 46, marginTop: 10, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  textActionLabel: { color: THEME.primary, fontSize: 13, lineHeight: 18, fontWeight: "800" },
  notice: { flexDirection: "row", gap: 12, backgroundColor: THEME.white, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: THEME.border, marginBottom: 14 },
  noticeCopy: { flex: 1 },
  noticeTitle: { color: THEME.ink, fontSize: 15, lineHeight: 20, fontWeight: "800" },
  noticeBody: { color: THEME.muted, fontSize: 12, lineHeight: 18, marginTop: 4 },
  darkCard: { backgroundColor: THEME.dark, borderRadius: 23, padding: 20 },
  darkCardTitle: { color: THEME.white, fontSize: 22, lineHeight: 28, fontWeight: "900" },
  darkCardBody: { color: "#C9D7E8", fontSize: 13, lineHeight: 20, marginVertical: 10 },
  formCard: { backgroundColor: THEME.white, borderRadius: 23, padding: 18, borderWidth: 1, borderColor: THEME.border },
  field: { marginBottom: 15 },
  fieldLabel: { color: THEME.ink, fontSize: 12, lineHeight: 17, fontWeight: "800", marginBottom: 7 },
  input: { minHeight: 50, borderRadius: 14, borderWidth: 1, borderColor: "#CBD6E4", backgroundColor: THEME.background, color: THEME.ink, fontSize: 15, paddingHorizontal: 14 },
  inputMultiline: { minHeight: 128, paddingTop: 13, paddingBottom: 13 },
  inputError: { borderColor: THEME.error, backgroundColor: "#FFF7F6" },
  errorText: { color: THEME.error, fontSize: 11, lineHeight: 16, fontWeight: "700", marginTop: 5 },
  privacy: { color: THEME.muted, fontSize: 11, lineHeight: 17, marginTop: 12 },
  bottomNav: { minHeight: 70, flexDirection: "row", backgroundColor: THEME.dark, paddingTop: 7, paddingBottom: Platform.OS === "ios" ? 3 : 7 },
  tab: { flex: 1, alignItems: "center", justifyContent: "center" },
  tabText: { color: "#8492A7", fontSize: 9, lineHeight: 13, fontWeight: "700", marginTop: 3 },
  tabTextActive: { color: THEME.accent },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(2,6,15,0.92)", padding: 14, alignItems: "center", justifyContent: "center" },
  modalPanel: { width: "100%", height: "84%", borderRadius: 23, overflow: "hidden", backgroundColor: THEME.white },
  modalHeader: { minHeight: 64, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", borderBottomWidth: 1, borderBottomColor: THEME.border },
  modalTitle: { flex: 1, color: THEME.ink, fontSize: 15, lineHeight: 20, fontWeight: "800", paddingRight: 10 },
  closeButton: { width: 42, height: 42, borderRadius: 21, alignItems: "center", justifyContent: "center", backgroundColor: THEME.background },
  modalImage: { flex: 1, width: "100%", backgroundColor: "#E9EEF5" },
});
