# {{APP_NAME}} — Expo Snack Handoff

This folder is a portable React Native edition designed for a blank Expo Snack using Expo SDK 54. It uses one `App.js`, local assets, React Native core APIs, and `@expo/vector-icons`.

## Start in Expo Snack

1. Open [Expo Snack](https://snack.expo.dev/) and create a blank SDK 54 Snack.
2. Replace its `App.js` with this package’s `App.js`.
3. Create an `assets` folder and upload every file from this package’s `assets` folder.
4. Confirm that `@expo/vector-icons` is listed under dependencies.
5. Select **My Device** and scan the QR code with Expo Go.

## Verified Behavior

The bottom navigation changes screens, gallery images open and close, service actions prefill the inquiry, required contact fields validate, and the final action opens the device email composer.

## Release Values

Before public release, confirm `CONTACT_EMAIL`, production URLs, factual claims, outcome metrics, legal statements, and image rights. Remove any screen or interaction that is not part of the approved scope.
