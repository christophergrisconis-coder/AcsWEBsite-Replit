#!/usr/bin/env python3
"""Validate the portable structure and obvious runtime risks of an Expo Snack package."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path


REQUIRED_FILES = ("App.js", "app.json", "package.json", "HANDOFF.md", "assets/icon.png")
BUILTIN_IMPORTS = {"react", "react-native"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate a portable Expo Snack folder.")
    parser.add_argument("--snack-dir", required=True, type=Path, help="Path to the Snack package directory.")
    parser.add_argument("--sdk-major", type=int, default=54, help="Expected Expo SDK major version.")
    parser.add_argument(
        "--max-asset-mb",
        type=float,
        default=5.0,
        help="Warn when a single local asset exceeds this size.",
    )
    return parser.parse_args()


def load_json(path: Path, errors: list[str]) -> dict:
    try:
        with path.open("r", encoding="utf-8") as handle:
            value = json.load(handle)
        if not isinstance(value, dict):
            errors.append(f"{path.name} must contain a JSON object.")
            return {}
        return value
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"Unable to parse {path.name}: {exc}")
        return {}


def package_root(import_name: str) -> str:
    if import_name.startswith("@"):
        pieces = import_name.split("/")
        return "/".join(pieces[:2]) if len(pieces) >= 2 else import_name
    return import_name.split("/")[0]


def main() -> int:
    args = parse_args()
    snack_dir = args.snack_dir.expanduser().resolve()
    errors: list[str] = []
    warnings: list[str] = []

    if not snack_dir.is_dir():
        print(f"ERROR: Snack directory does not exist: {snack_dir}")
        return 1

    for relative in REQUIRED_FILES:
        if not (snack_dir / relative).is_file():
            errors.append(f"Missing required file: {relative}")

    app_source_path = snack_dir / "App.js"
    package_path = snack_dir / "package.json"
    app_json_path = snack_dir / "app.json"
    if not app_source_path.exists() or not package_path.exists() or not app_json_path.exists():
        for error in errors:
            print(f"ERROR: {error}")
        return 1

    source = app_source_path.read_text(encoding="utf-8")
    package_json = load_json(package_path, errors)
    app_json = load_json(app_json_path, errors)
    dependencies = package_json.get("dependencies", {})
    if not isinstance(dependencies, dict):
        errors.append("package.json dependencies must be an object.")
        dependencies = {}

    expo_version = str(dependencies.get("expo", ""))
    expo_major_match = re.search(r"(\d+)", expo_version)
    if not expo_major_match:
        errors.append("package.json must declare an Expo dependency.")
    elif int(expo_major_match.group(1)) != args.sdk_major:
        errors.append(
            f"Expo dependency {expo_version!r} does not match expected SDK major {args.sdk_major}."
        )

    imports = re.findall(r"from\s+[\"']([^\"']+)[\"']", source)
    imports.extend(re.findall(r"import\s+[\"']([^\"']+)[\"']", source))
    for import_name in sorted(set(imports)):
        if import_name.startswith((".", "/")):
            continue
        root = package_root(import_name)
        if root not in BUILTIN_IMPORTS and root not in dependencies:
            errors.append(f"Imported package is not declared in package.json: {root}")

    unresolved = sorted(set(re.findall(r"\{\{[A-Z0-9_]+\}\}", source)))
    if unresolved:
        errors.append(f"Unresolved template tokens in App.js: {', '.join(unresolved)}")

    asset_paths = re.findall(r"require\(\s*[\"']([^\"']+)[\"']\s*\)", source)
    for raw_path in sorted(set(asset_paths)):
        if not raw_path.startswith("."):
            errors.append(f"Local assets must use relative require paths: {raw_path}")
            continue
        asset_path = (snack_dir / raw_path).resolve()
        try:
            asset_path.relative_to(snack_dir)
        except ValueError:
            errors.append(f"Asset path escapes the Snack directory: {raw_path}")
            continue
        if not asset_path.is_file():
            errors.append(f"Missing local asset referenced by App.js: {raw_path}")
        elif asset_path.stat().st_size > args.max_asset_mb * 1024 * 1024:
            warnings.append(
                f"Large local asset ({asset_path.stat().st_size / 1024 / 1024:.1f} MB): {raw_path}"
            )

    expo_config = app_json.get("expo", {}) if isinstance(app_json.get("expo", {}), dict) else {}
    icon_path = expo_config.get("icon")
    if not icon_path:
        errors.append("app.json must define expo.icon.")
    elif not (snack_dir / str(icon_path)).resolve().is_file():
        errors.append(f"app.json icon does not exist: {icon_path}")

    if "<Pressable" in source and "onPress=" not in source:
        errors.append("App.js contains Pressable controls but no onPress handlers.")
    if "mailto:" in source and "Linking.openURL" not in source:
        errors.append("App.js contains a mailto URL but does not invoke Linking.openURL.")
    if re.search(r'const\s+CONTACT_EMAIL\s*=\s*["\']\s*["\']', source):
        warnings.append("CONTACT_EMAIL is empty; set a verified recipient before public release.")
    if "Alert.alert" not in source and "Linking.openURL" in source:
        warnings.append("External linking has no visible Alert fallback in App.js.")

    for warning in warnings:
        print(f"WARN: {warning}")
    for error in errors:
        print(f"ERROR: {error}")

    if errors:
        print(f"FAILED: {len(errors)} error(s), {len(warnings)} warning(s).")
        return 1

    print(f"PASS: Snack package validated with {len(warnings)} warning(s).")
    print(f"Checked {len(set(asset_paths))} local asset reference(s) and {len(set(imports))} import(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
