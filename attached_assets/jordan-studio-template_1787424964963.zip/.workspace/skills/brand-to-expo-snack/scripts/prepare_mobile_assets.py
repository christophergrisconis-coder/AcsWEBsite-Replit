#!/usr/bin/env python3
"""Prepare mobile campaign artwork and app icons for Expo and Snack.

Example:
    python3 prepare_mobile_assets.py \
      --manifest /path/to/asset-manifest.json \
      --project-root /path/to/expo-project
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from PIL import Image


PROJECT_ICON_PATHS = (
    "assets/images/icon.png",
    "assets/images/splash-icon.png",
    "assets/images/favicon.png",
    "assets/images/android-icon-foreground.png",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Resize and compress visual assets for an Expo project and portable Snack package."
    )
    parser.add_argument("--manifest", required=True, type=Path, help="Path to the asset manifest JSON file.")
    parser.add_argument("--project-root", required=True, type=Path, help="Root of the managed Expo project.")
    parser.add_argument(
        "--snack-dir",
        type=Path,
        help="Portable Snack directory. Defaults to <project-root>/snack.",
    )
    return parser.parse_args()


def load_manifest(path: Path) -> dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Manifest does not exist: {path}")
    with path.open("r", encoding="utf-8") as handle:
        manifest = json.load(handle)
    if not isinstance(manifest.get("images", []), list):
        raise ValueError("Manifest field 'images' must be a list.")
    return manifest


def resolve_source(raw_path: str, manifest_dir: Path) -> Path:
    source = Path(raw_path).expanduser()
    if not source.is_absolute():
        source = manifest_dir / source
    source = source.resolve()
    if not source.exists():
        raise FileNotFoundError(f"Source asset does not exist: {source}")
    return source


def resize_preserving_ratio(image: Image.Image, max_width: int) -> Image.Image:
    if max_width <= 0:
        raise ValueError("max_width must be greater than zero.")
    if image.width <= max_width:
        return image.copy()
    target_height = round(image.height * (max_width / image.width))
    return image.resize((max_width, target_height), Image.Resampling.LANCZOS)


def save_artwork(source: Path, destination: Path, max_width: int, quality: int) -> None:
    suffix = destination.suffix.lower()
    destination.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as opened:
        resized = resize_preserving_ratio(opened, max_width)
        if suffix in {".jpg", ".jpeg"}:
            if resized.mode in {"RGBA", "LA"}:
                flattened = Image.new("RGB", resized.size, "white")
                flattened.paste(resized, mask=resized.getchannel("A"))
                resized = flattened
            else:
                resized = resized.convert("RGB")
            resized.save(destination, "JPEG", quality=quality, optimize=True, progressive=True)
        elif suffix == ".png":
            resized.convert("RGBA").save(destination, "PNG", optimize=True)
        else:
            raise ValueError(f"Unsupported output format for {destination}; use .jpg, .jpeg, or .png.")


def save_icon(source: Path, destination: Path, size: int) -> None:
    if size <= 0:
        raise ValueError("icon_size must be greater than zero.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as opened:
        icon = opened.convert("RGBA")
        if icon.size != (size, size):
            icon = icon.resize((size, size), Image.Resampling.LANCZOS)
        icon.save(destination, "PNG", optimize=True)


def main() -> int:
    args = parse_args()
    manifest_path = args.manifest.expanduser().resolve()
    project_root = args.project_root.expanduser().resolve()
    snack_dir = (args.snack_dir or project_root / "snack").expanduser().resolve()
    manifest = load_manifest(manifest_path)

    project_assets = project_root / "assets" / "images"
    snack_assets = snack_dir / "assets"
    project_assets.mkdir(parents=True, exist_ok=True)
    snack_assets.mkdir(parents=True, exist_ok=True)

    prepared: list[str] = []
    for item in manifest.get("images", []):
        source = resolve_source(str(item["source"]), manifest_path.parent)
        filename = str(item["filename"])
        if Path(filename).name != filename:
            raise ValueError(f"Image filename must not contain directories: {filename}")
        max_width = int(item.get("max_width", 1600))
        quality = int(item.get("quality", 86))
        if not 1 <= quality <= 95:
            raise ValueError(f"JPEG quality must be between 1 and 95 for {filename}.")

        project_destination = project_assets / filename
        snack_destination = snack_assets / filename
        save_artwork(source, project_destination, max_width, quality)
        save_artwork(source, snack_destination, max_width, quality)
        prepared.append(f"{filename}: {project_destination.stat().st_size} bytes")

    icon_raw = manifest.get("icon_source")
    if icon_raw:
        icon_source = resolve_source(str(icon_raw), manifest_path.parent)
        icon_size = int(manifest.get("icon_size", 1024))
        for relative_path in PROJECT_ICON_PATHS:
            save_icon(icon_source, project_root / relative_path, icon_size)
        save_icon(icon_source, snack_assets / "icon.png", icon_size)
        prepared.append(f"icon.png: {icon_size}x{icon_size}")

    print("Prepared Expo and Snack assets:")
    for entry in prepared:
        print(f"- {entry}")
    if not prepared:
        print("- No images were listed in the manifest.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
