#!/usr/bin/env python3
"""Render the bundled tokenized Snack template from a JSON configuration file."""

from __future__ import annotations

import argparse
import json
import re
import shutil
from pathlib import Path


TOKEN_PATTERN = re.compile(r"\{\{([A-Z0-9_]+)\}\}")
TEXT_SUFFIXES = {".js", ".json", ".md", ".txt"}


def parse_args() -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    default_template = script_dir.parent / "templates" / "snack"
    parser = argparse.ArgumentParser(description="Render a portable Expo Snack package from templates.")
    parser.add_argument("--config", required=True, type=Path, help="JSON object containing template values.")
    parser.add_argument("--output-dir", required=True, type=Path, help="Destination Snack directory.")
    parser.add_argument("--template-dir", type=Path, default=default_template, help="Template directory.")
    parser.add_argument("--overwrite", action="store_true", help="Replace an existing output directory.")
    return parser.parse_args()


def escape_quoted_value(value: object) -> str:
    text = str(value)
    return text.replace("\\", "\\\\").replace('"', '\\"').replace("\r", "").replace("\n", "\\n")


def render_text(text: str, values: dict[str, object], suffix: str) -> str:
    missing = sorted({token for token in TOKEN_PATTERN.findall(text) if token not in values})
    if missing:
        raise ValueError(f"Missing template values: {', '.join(missing)}")

    def replacement(match: re.Match[str]) -> str:
        value = values[match.group(1)]
        return str(value) if suffix == ".md" else escape_quoted_value(value)

    rendered = TOKEN_PATTERN.sub(replacement, text)
    unresolved = sorted(set(TOKEN_PATTERN.findall(rendered)))
    if unresolved:
        raise ValueError(f"Unresolved template values: {', '.join(unresolved)}")
    return rendered


def main() -> int:
    args = parse_args()
    config_path = args.config.expanduser().resolve()
    template_dir = args.template_dir.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()

    with config_path.open("r", encoding="utf-8") as handle:
        values = json.load(handle)
    if not isinstance(values, dict):
        raise ValueError("Template configuration must be a JSON object.")
    if not template_dir.is_dir():
        raise FileNotFoundError(f"Template directory does not exist: {template_dir}")

    if output_dir.exists():
        if not args.overwrite:
            raise FileExistsError(f"Output directory already exists: {output_dir}; pass --overwrite to replace it.")
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)

    rendered_files = 0
    for source in sorted(template_dir.rglob("*")):
        relative = source.relative_to(template_dir)
        destination = output_dir / relative
        if source.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source.suffix.lower() in TEXT_SUFFIXES:
            text = source.read_text(encoding="utf-8")
            destination.write_text(render_text(text, values, source.suffix.lower()), encoding="utf-8")
        else:
            shutil.copy2(source, destination)
        rendered_files += 1

    print(f"Rendered {rendered_files} Snack template file(s) to {output_dir}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
